<?php

return  [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=realestate',
    'username' => 'root',
    'password' => 'qwe'
];